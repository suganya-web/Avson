// window.onscroll = function() {stickyHeader()};

// var header = document.getElementById("header");
// var sticky = header.offsetTop;
// var minWidth = 798;

// function stickyHeader() {
//     if (window.innerWidth >= minWidth) {
//         if (window.pageYOffset > sticky) {
//             header.classList.add("sticky-header");
//         } else {
//             header.classList.remove("sticky-header");
//         }
//     } else {
//         header.classList.remove("sticky-header");
//     }
// }

// window.addEventListener('resize', stickyHeader);

// window.addEventListener('load', stickyHeader);